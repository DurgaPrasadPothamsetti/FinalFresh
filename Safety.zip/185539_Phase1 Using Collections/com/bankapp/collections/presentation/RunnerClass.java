package com.bankapp.collections.presentation;

import java.util.List;


import java.util.Scanner;

import com.bankapp.collections.bean.AccountDetails;
import com.bankapp.collections.bean.TransactionDetails;
import com.bankapp.collections.service.ServiceLayer;

public class RunnerClass {
	static Scanner scannerobj = new Scanner(System.in);
	static ServiceLayer serviceobj = new ServiceLayer();

	public static void main(String[] args) {

	
		for (;;) {
			System.out.println();
			System.out.print(
					"1. Create Account\n"
					+ "2. Show Balance\n"
					+ "3. Deposit\n"
					+ "4. Withdraw\n"
					+ "5. Fund Transfer\n"
					+ "6. Print Transactions\n"
					+ "7. Exit\n"
					+ "Enter Your Choice: ");
			int userchoice = scannerobj.nextInt();
			switch (userchoice) {
			case 1: {
				AccountDetails account = new AccountDetails();
				System.out.print("Please Enter Your Name:");
				String username=scannerobj.next();
				account.setName(username);
				account.setAccountNumber((int) (Math.random() * 1000));
				System.out.println("Your Account Created Successfully!!");
				System.out.println("Your Account Number is: " + account.getAccountNumber());
				System.out.print("Now Enter your first Deposit: ");
				double userdep=scannerobj.nextDouble();
				account.setAmount(userdep);
				serviceobj.createNewAccount(account);

			}
				break;
			case 2: {
				System.out.print("Please Enter Your Account Number: ");
				System.out.println("Your Account Balance is: " + serviceobj.showBalance(AccNumberValidation()));
			}
				break;
			case 3: {
				System.out.print("Enter Your Account Number: ");
				int accountNumber = AccNumberValidation();
				System.out.print("Enter the amount you want to deposit: ");
				double credit = scannerobj.nextInt();
				System.out.println("Balance credited to account: " + accountNumber + "\nCredited: " + credit
						+ "\nAvailable balance is: " + serviceobj.depositAmount(accountNumber, credit));
			}
				break;
			case 4: {
				System.out.print("Enter Account Number: ");
				int accountNumber = AccNumberValidation();
				System.out.print("Enter the amount you want to withdraw: ");
				double debit = scannerobj.nextInt();
				System.out.println("Balance debited from account: " + accountNumber + "\nDebited: " + debit
						+ "\nAvailable balance is: " + serviceobj.withdrawAmount(accountNumber, debit));
			}
				break;
			case 5: {
				System.out.print("Enter Your Account Number: ");
				int senderAccountNumber = AccNumberValidation();
				System.out.print("Enter Receiver Account Number: ");
				int receiverAccountNumber = AccNumberValidation();
				System.out.print("Enter the amount you want to transfer: ");
				double transferAmount = scannerobj.nextInt();
				System.out.println("Balance debited from account: " + senderAccountNumber + " is " + transferAmount
						+ "\nBalance credited to account: " + receiverAccountNumber + "\nAvailable balance is: "
						+ serviceobj.fundTransfer(senderAccountNumber, receiverAccountNumber, transferAmount));
			}
				break;
			case 6: {
				System.out.print("Enter Account Number: ");
				int accountNumber = AccNumberValidation();
				List<TransactionDetails> resultList = serviceobj.getTransactionData(accountNumber);
				System.out.println("Transaction List: ");
				for (TransactionDetails transactionDetails : resultList)
					System.out.println(transactionDetails);
			}
				break;
			case 7:
				System.out.println("Exited....");
				scannerobj.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice..Try again");
				break;
			}
		}
		
	}
	
	public static int AccNumberValidation() {
		int accountNumber=0;
		while(true) {
		accountNumber=scannerobj.nextInt();
		if(serviceobj.validateAccountNumber(accountNumber))
			return accountNumber;
		else {
		System.out.println("Account Number Doesn't Exist\nEnter Account Number Again: ");
		}
		}
	}
}
