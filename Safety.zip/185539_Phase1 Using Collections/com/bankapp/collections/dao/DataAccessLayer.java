package com.bankapp.collections.dao;

import java.util.ArrayList;
import java.util.List;

import com.bankapp.collections.bean.AccountDetails;
import com.bankapp.collections.bean.TransactionDetails;

public class DataAccessLayer {
	List<AccountDetails> accountList= new ArrayList<>();
	List<TransactionDetails> transactionList= new ArrayList<>();
	
	public void setAccountList(AccountDetails account) {
		
		accountList.add(account);
		
	
	}
	public void setTransactionList(TransactionDetails transaction) {
		transactionList.add(transaction);
	}
	public List<AccountDetails> getAllAccounts(){
		return accountList;
		
	}
	public List<TransactionDetails> getTransactionList(){
		return transactionList;
	}
	
}
