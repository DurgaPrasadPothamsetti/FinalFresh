package com.bankapp.collections.service;



import java.util.ArrayList;
import java.util.List;

import com.bankapp.collections.bean.AccountDetails;
import com.bankapp.collections.bean.TransactionDetails;
import com.bankapp.collections.dao.DataAccessLayer;

public class ServiceLayer {
	DataAccessLayer data=new DataAccessLayer();
	
	public void createNewAccount(AccountDetails account2) {
		TransactionDetails transaction=new TransactionDetails();
		data.setAccountList(account2);
		transaction.setAccountNumber(account2.getAccountNumber());
		transaction.setCredit(account2.getAmount());
		transaction.setDebit(0);
		transaction.setAmount(account2.getAmount());
		data.setTransactionList(transaction);
	}
	public boolean validateAccountNumber(int accountNumber) {
		 List<AccountDetails> accountList=data.getAllAccounts();
			for(AccountDetails accountDetail:accountList) {
				if(accountNumber==accountDetail.getAccountNumber())
			return true;
			}
			return false;
	}
	

	public double depositAmount(int accountNumber,double credit) {
       List<AccountDetails> accountList=data.getAllAccounts();
		
		for(AccountDetails accountDetail:accountList) {
			
			if(accountNumber==accountDetail.getAccountNumber()) {
				TransactionDetails transaction=new TransactionDetails();
				double balance=accountDetail.getAmount();
				
				accountDetail.setAmount(balance+credit);
				transaction.setAccountNumber(accountDetail.getAccountNumber());
				transaction.setCredit(credit);
				transaction.setDebit(0);
				transaction.setAmount(accountDetail.getAmount());
				data.setTransactionList(transaction);
				return accountDetail.getAmount(); 
			}
		}
		
        return 0;		
		
	}
	public double showBalance(int accountNumber) {
		List<AccountDetails> accountList=data.getAllAccounts();
		
		for(AccountDetails accountDetail:accountList) {
			
			if(accountNumber==accountDetail.getAccountNumber()) {
				return accountDetail.getAmount();
			}
		}
		return 0;
		
	}
	
	public double fundTransfer(int senderAccountNumber, int receiverAccountNumber, double transferAmount) {
		double returnAmount=0;
		 List<AccountDetails> accountList=data.getAllAccounts();
			
			for(AccountDetails accountDetail:accountList) {
				if(senderAccountNumber==accountDetail.getAccountNumber()) {
					accountDetail.setAmount(accountDetail.getAmount()-transferAmount);
					TransactionDetails transaction=new TransactionDetails();
					transaction.setAccountNumber(accountDetail.getAccountNumber());
					transaction.setCredit(0);
					transaction.setDebit(transferAmount);
					transaction.setAmount(accountDetail.getAmount());
					data.setTransactionList(transaction);
					returnAmount= accountDetail.getAmount(); 
				}
				if(receiverAccountNumber==accountDetail.getAccountNumber()) {
					accountDetail.setAmount(accountDetail.getAmount()+transferAmount);
					TransactionDetails transaction=new TransactionDetails();
					transaction.setAccountNumber(accountDetail.getAccountNumber());
					transaction.setCredit(transferAmount);
					transaction.setDebit(0);
					transaction.setAmount(accountDetail.getAmount());
					data.setTransactionList(transaction);
					
				}
			}
			return returnAmount;
	}
	public double withdrawAmount(int accountNumber, double debit) {
	       List<AccountDetails> accountList=data.getAllAccounts();
			
			for(AccountDetails accountDetail:accountList) {
				
				if(accountNumber==accountDetail.getAccountNumber()) {
					TransactionDetails transaction=new TransactionDetails();
					double balance=accountDetail.getAmount();
					accountDetail.setAmount(balance-debit);
					transaction.setAccountNumber(accountDetail.getAccountNumber());
					transaction.setCredit(0);
					transaction.setDebit(debit);
					transaction.setAmount(accountDetail.getAmount());
					data.setTransactionList(transaction);
					return accountDetail.getAmount(); 
				}
			}
			return 0;
		}
	public List<TransactionDetails> getTransactionData(int accountNumber) {
		List<TransactionDetails> transactionList=data.getTransactionList();
		List<TransactionDetails> transactionList2=new ArrayList<>();
		for(TransactionDetails transactionDetail:transactionList) {
			if(accountNumber==transactionDetail.getAccountNumber()) {
				transactionList2.add(transactionDetail);
			}
			
		}
		return transactionList2;
	}


	
}
