package com.mybank.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mybank.bean.BankAppBeanClass;

@Repository
public interface DataAccessLayer extends JpaRepository<BankAppBeanClass, Integer> {

	@Query("from BankAppBeanClass where userName=:userName")
    BankAppBeanClass getUserDetails(@Param("userName") String userName);
   
	
    @Query("from BankAppBeanClass where userName=:userName")
    BankAppBeanClass getDetailsByUser(@Param("userName")String username);
   
    @Query("from BankAppBeanClass where accountNumber=:accno")
    BankAppBeanClass getDetailsById(@Param("accno") int accountNumber);
}
