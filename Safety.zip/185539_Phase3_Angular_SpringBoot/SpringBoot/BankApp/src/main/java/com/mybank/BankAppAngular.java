package com.mybank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppAngular {

	public static void main(String[] args) {
		SpringApplication.run(BankAppAngular.class, args);
	}

}
