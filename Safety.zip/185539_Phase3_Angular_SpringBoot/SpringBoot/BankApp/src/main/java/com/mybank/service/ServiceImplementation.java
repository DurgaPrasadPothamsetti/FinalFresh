package com.mybank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybank.bean.BankAppBeanClass;
import com.mybank.dao.DataAccessLayer;
import com.mybank.exception.BankException;

@Service
public class ServiceImplementation implements ServiceInterface {
	@Autowired
	DataAccessLayer bankDao;

	@Override
	public void createAccount(BankAppBeanClass bankDetails) throws BankException {
		// TODO Auto-generated method stub
		bankDao.save(bankDetails);
	}

	@Override
	public List<BankAppBeanClass> viewAccounts() throws BankException {
		// TODO Auto-generated method stub
		return bankDao.findAll();
	}

	@Override
	public BankAppBeanClass getDetailsById(int accountNumber) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.findById(accountNumber).get();
	}

	@Override
	public BankAppBeanClass showBalance(int accountNumber) throws BankException {

		// TODO Auto-generated method stub
		return bankDao.getDetailsById(accountNumber);
	}

	@Override
	public int withdraw(int accountNumber, int amount) throws BankException {
		// TODO Auto-generated method stub
		 BankAppBeanClass temp = bankDao.getDetailsById(accountNumber);
         int currentBalance = temp.getAmount();
         int updatedBalance = currentBalance-amount;
         temp.setAmount(updatedBalance);
         bankDao.save(temp);
         return updatedBalance;
	}

	@Override
	public int deposit(int accountNumber, int amount) throws BankException {
		// TODO Auto-generated method stub

		BankAppBeanClass temp = bankDao.getDetailsById(accountNumber);
		int currentBalance = temp.getAmount();
		int updatedBalance = amount + currentBalance;
		temp.setAmount(updatedBalance);
		bankDao.save(temp);
		return updatedBalance;
	}

	@Override
	public boolean fundTransfer(int sender, int receiver, int amount) throws BankException {
		// TODO Auto-generated method stub
		 BankAppBeanClass temp = bankDao.getDetailsById(sender);
         int currentBalance1 = temp.getAmount();
         int updatedBalance1 = amount + currentBalance1;
         temp.setAmount(updatedBalance1);
         bankDao.save(temp);
         BankAppBeanClass temp2 = bankDao.getDetailsById(receiver);
        int currentBalance2 = temp2.getAmount();
         int updatedBalance2 = currentBalance2-amount;
         temp2.setAmount(updatedBalance2);
         
         return true;
	}

	@Override
	public List<BankAppBeanClass> getTransactions() throws BankException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public BankAppBeanClass getDetailsByUsername(String username) throws BankException {
		// TODO Auto-generated method stub
		return bankDao.getDetailsByUser(username);
	}
}
